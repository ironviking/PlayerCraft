----PLAYERCRAFT----

Author: Ironviking
Version: Alpha first release (1.0.1)

Installation
###############
1 - Edit database configuration in application->config->database.php to your MySQL settings.
2 - Edit user configuration for admin login in application->config->user.php
3 - Make sure the admin login works by going to yourdomain/login
4 - You can now start editing your website :-) 

Bugs and feedback
###############
http://bit.ly/PjSLx8

License
###############
Use it however  you want (horray!) but please do not redistrubt it or 
take credits for it (I put a lot of time on this). You dont need to put 
any link to the thread or software label unless you want to (i'd apperciate it) 
