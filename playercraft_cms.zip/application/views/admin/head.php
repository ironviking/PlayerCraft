<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html LANG="EN">
<head>
    <title>PlayerCraft - Admin</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link href="<?=base_url()?>css/admin.css" rel="stylesheet"> 
	<link href="<?=base_url()?>css/style.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="favicon.png">
    <link href='http://fonts.googleapis.com/css?family=Press+Start+2P' rel='stylesheet' type='text/css'>
   <SCRIPT language="JavaScript">
   function fixie(){if (browserName=navigator.appName=="Microsoft Internet Explorer"){document.body.style.background = '#80B5FE';}}
   function NewPage(){document.getElementById('NewPageBox').style.display='block';}
   function NoNewPage(){document.getElementById('NewPageBox').style.display='none';}
   function NewWidget(){document.getElementById('NewWidgetBox').style.display='block';}
   function NoNewWidget(){document.getElementById('NewWidgetBox').style.display='none';}
   </SCRIPT>

</head>
<body onload="fixie();">
<script src="js/cst.js" type="javascript/text"></script>
<img src="<?=base_url()?>images/sun.png" class="sun">
	<div id="page">
		<div id="container">
			<div id="logo">
				<a href="<?=base_url()?>"><img src="<?=base_url()?>images/adm_logo.png"></a>
			</div>
