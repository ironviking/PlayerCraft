	<!-- Sidebar !-->
		<div id="aside">
	                <div class="widget">
	                     <h4>PlayerCraft feed</h4>
	                     <p>#No data#</p>
	               </div>
		</div>