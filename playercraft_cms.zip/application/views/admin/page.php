<div id="content">
    <select>
    	<option>Start</option>
    	<option>Join us</option>
    </select>
</div>