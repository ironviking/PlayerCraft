<div id="content">
	<form action="" method="POST"><input type="submit" name="logout" class="button" value="Logout"></form>
	<br /><br />
	<h4>SEO</h4>
		<p>Site title</p>
			<strong><?=$title?></strong>
		<p>Site description</p>
			<strong><?=$description?></strong>
			<div id="desc">
				<p>SEO configuration [root\application\config\site.php]</p>
			</div>
</div>
