	<div id="clear">
			. <!-- Clears float, don't remove this !-->
		</div>
	</div>	
	</div> <!-- End of #page -->
</body>
</html>