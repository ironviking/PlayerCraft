<div id="menu">
	<ul>
            <a href="<?=base_url()?>admin"><li>Pages</li></a>
            <a href="<?=base_url()?>admin/widgets"><li>Widgets</li></a>
            <a href="<?=base_url()?>admin/misc"><li>Misc</li></a>
	</ul>
</div><!-- End of #menu-->
