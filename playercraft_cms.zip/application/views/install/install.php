<html>
	<head>
		<title>Playercraft - install</title>
	</head>
	<body>
		<p>This will Create 2 tables in your database, Sure you want to continue?</p>
		<form action="" method="post"><input type="submit" name="install" value="Yes!"></form>
		
	</body>
</html>