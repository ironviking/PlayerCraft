<div id="content">
      <?=$pageContent?>
</div>