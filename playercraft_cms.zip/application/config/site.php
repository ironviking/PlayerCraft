<?php

# SEO
$config['title'] = 'A minecraft website';
$config['description'] = 'A minecraft server!';

# Will set the site in maintence making no one avaible to acceess it.
# TRUE/FALSE
$config['maintence_mode'] = FALSE;
