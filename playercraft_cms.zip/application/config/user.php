<?php
$config['user'] = 'admin';
$config['password'] = '';
